"""Consent-based desktop companions."""
